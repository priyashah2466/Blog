import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-login-nav-bar',
  templateUrl: './login-nav-bar.component.html',
  styleUrls: ['./login-nav-bar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class LoginNavBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
