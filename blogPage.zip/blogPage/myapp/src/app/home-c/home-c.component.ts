import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-home-c',
  templateUrl: './home-c.component.html',
  styleUrls: ['./home-c.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class HomeCComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
